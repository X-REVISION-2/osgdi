//to compile: cl sines.cpp /link user32.lib gdi32.lib shell32.lib
#include <windows.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <time.h>
#include <thread>
#include <atomic>

std::atomic<bool> g_shouldExit(false);
#define M_PI   3.14159265358979323846264338327950288
DWORD WINAPI cur(LPVOID lpParam) {
	POINT cursor;
	while (1) {
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		GetCursorPos(&cursor);
		DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_ERROR));
		ReleaseDC(0, hdc);
		//Sleep(10);
	}
	return(1);
}
DWORD WINAPI sines1(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	for (int t = 0; ; t += 20)
	{
		hdc = GetDC(NULL);
		for (int x = 0; x <= w; x++)
		{
			float y = sin((x + t) * (M_PI / 50)) * 25;
			BitBlt(hcdc, x, y, 1, h, hcdc, x, 0, SRCCOPY);
		}
		BLENDFUNCTION blend =
		{
			AC_SRC_OVER, 0, 111, 0
		};
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
	}
	ReleaseDC(NULL, hcdc);
	DeleteObject(hcdc);
	DeleteObject(hBitmap);
	return 0;
}
int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	Sleep(5000);
    HANDLE thread0 = CreateThread(0, 0, sines1, 0, 0, 0);
	HANDLE thread1 = CreateThread(0, 0, cur, 0, 0, 0);
	Sleep(30000);
	TerminateThread(thread0, 0);
	CloseHandle(thread0);
    TerminateThread(thread1, 0);
	CloseHandle(thread1);
	InvalidateRect(0, 0, 0);
	Sleep(100);
}